package server.ai;

/**
 * An enum representing the selected AI difficulty
 *
 * @author Daniel Batchford
 */
public enum Difficulty {EASY, MEDIUM, HARD}